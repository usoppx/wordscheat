php bang.php

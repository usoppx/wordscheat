<?php

//fb api setup
define('FACEBOOK_SDK_V4_SRC_DIR', __DIR__.'/Facebook/');

echo 'dir: ' . __DIR__ . '<br>';

require_once(__DIR__.'/Facebook/autoload.php');


if (!$link = mysql_connect('sql306.epizy.com', 'epiz_20436512', 'Alfredchicken1')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('epiz_20436512_sababa', $link)) {
    echo 'Could not select database';
    exit;
}

$sql    = 'SELECT * from priceDrop';
$result = mysql_query($sql, $link);

if (!$result) {
    echo "DB Error, could not query the database\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}

$pubDate = '';
while ($row = mysql_fetch_assoc($result)) {
    //echo 'pubDate: ' . $row['pubDate'].'<br>';
	$pubDate = $row['pubDate'];
}

$time = strtotime($pubDate);
$time = date('Y-m-d h:i:s', $time);
//$newformat = date('Y-m-d',$time);
$pubDate2 = $time;

echo 'postPUBTIME: ' . $time .'<br>';

mysql_free_result($result);


$fb = new Facebook\Facebook([
 'app_id' => '1917572348517707',
 'app_secret' => '95055a6959d3808c589872cb75847f2e',
 'default_graph_version' => 'v2.10',
]);

/*
//get fb access token
$app_id = '1917572348517707';
$app_secret = '95055a6959d3808c589872cb75847f2e';
$access_token = "https://graph.facebook.com/oauth/access_token?client_id=$app_id&client_secret=$app_secret&grant_type=client_credentials";
$access_token = file_get_contents($access_token); // returns 'accesstoken=APP_TOKEN|APP_SECRET'
//$access_token = str_replace('access_token=', '', $access_token);

echo 'access_token: ' . $access_token . '<br><br>';
*/
/*
$app_id = '1917572348517707';
$app_secret = '95055a6959d3808c589872cb75847f2e';
$access_token_url = "https://graph.facebook.com/oauth/access_token?client_id=$app_id&client_secret=$app_secret&grant_type=client_credentials";
$access_token_data = file_get_contents($access_token_url);
$access_token_arr = json_decode($access_token_data);
$access_token = $access_token_arr->access_token;

echo 'atoken: ' .$access_token.'<br>';
*/
//get camel rss
$xml = simplexml_load_file("https://camelcamelcamel.com/top_drops/feed?bn=electronics&t=recent&i=1&s=relative&d=10.0&");
/*
	$tmpPub = $xml->channel->item[0]->pubDate;
	echo 'prexmltime: ' . $tmpPub . '<br>';
	$time = strtotime($tmpPub);
	$time = date('Y-m-d h:i:s', $time);
	echo 'postxmltime: ' . $time . '<br>';

	if($tmpPub > $pubDate)
	{	echo 'true' . '<br>';
	}else
		echo 'false';
*/

$tmpPub = $xml->channel->item[0]->pubDate;
echo 'prexmltime: ' . $tmpPub . '<br>';
$time = strtotime($tmpPub);
$time = date('Y-m-d h:i:s', $time);
echo 'postxmltime: ' . $time . '<br>';
$tmpPub2 = $time; 

if($tmpPub2 > $pubDate2)
{	
	echo 'new items found' . '<br>';


	for($i=0; $i <1; $i++)
	{

		$tmpPub = $xml->channel->item[$i]->pubDate;
		//echo 'prexmltime['.$i.']: ' . $tmpPub . '<br>';
		$time = strtotime($tmpPub);
		$time = date('Y-m-d h:i:s', $time);
		echo 'postxmltime['.$i.']: ' . $time . '<br>';
		$tmpPub=$time;

		if($tmpPub > $pubDate2)
		{	
	
			echo $xml->channel->item[$i]->title.'<br>';
			$link = str_replace('https://camelcamelcamel.com/product/', 'https://www.amazon.com/dp/' , $xml->channel->item[$i]->link).'?tag=ricerops-20';
			echo $link.'<br>';
			echo $xml->channel->item[$i]->pubDate.'<br>';

			$linkData = [
			 'link' => ''.str_replace('https://camelcamelcamel.com/product/', 'https://www.amazon.com/dp/' , $xml->channel->item[$i]->link).'?tag=ricerops-20'.'',
			 'message' => ''.$xml->channel->item[$i]->title.''
			];
			$pageAccessToken = 'EAAbQBZAqqHUsBAICIDcLqPh5JnpS9c8g77mX606kR5iZBkoNFiJenqEYhZCz4PoFZAzqwHzZBb5xZBFdruVSCm0Sn5qJeViiugAfVYOed3y8OVZA8nS1jz9GIf0FUTZALGai2321QEkJctIdivVDZB1VZCjB6mGZClLwF1lZCzYid3UPZCwZDZD';

/*
select amazing price drops, copy access token
https://developers.facebook.com/tools/explorer/1917572348517707?method=GET&path=me&version=v2.10
go here
https://developers.facebook.com/tools/debug/accesstoken
click extend token
get new token, overwrite $pageaccesstoken above		
*/	
			
			try {
			 $response = $fb->post('/me/feed', $linkData, $pageAccessToken);
			} catch(Facebook\Exceptions\FacebookResponseException $e) {
			 echo 'Graph returned an error: '.$e->getMessage();
			 exit;
			} catch(Facebook\Exceptions\FacebookSDKException $e) {
			 echo 'Facebook SDK returned an error: '.$e->getMessage();
			 exit;
			}
			$graphNode = $response->getGraphNode();

			//sleep(2);
			
		}
	}

if (!$link = mysql_connect('sql306.epizy.com', 'epiz_20436512', 'Alfredchicken1')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('epiz_20436512_sababa', $link)) {
    echo 'Could not select database';
    exit;
}

	//update sql with new pubdate of latest item
	$sql    = "delete FROM priceDrop";
	echo $sql . '<br>';
	$result = mysql_query($sql, $link);

	if (!$result) {
		echo 'delete failed<br>';
		echo 'MySQL Error: ' . mysql_error() . '<br>';
	}else
		echo 'delete succeeded<br>';


	mysql_free_result($result);

	$sql    = "INSERT INTO priceDrop values('" . $xml->channel->item[0]->pubDate . "')";
	echo $sql . '<br>';
	$result = mysql_query($sql, $link);

	if (!$result) {
		echo 'insert failed<br>';
		echo 'MySQL Error: ' . mysql_error() . '<br>';
	}else
		echo 'insert succeeded<br>';

}else //no new items
	echo 'no new items' . '<br>';



?>

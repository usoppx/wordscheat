<?php

function fetch_curl($xmlURL, $post='',$enc='POST') {
    //echo '<br>URL: '.$xmlURL.'<br>';
    global $cookie;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $xmlURL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    $request_headers[] = "Content-type: application/json";
    //$request_headers[] = "Accept: */*";    
    curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);

    if (!empty($post)) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        //echo '<BR><BR>post: '.$post.'<BR><BR>';
    }

    $xmlData = curl_exec($ch);
    //echo '<br>error:' . print_r(curl_getinfo($ch)).'<br>';
    curl_close($ch);
    unset($ch);
    //sleep(0.25);
    return $xmlData;
}


//fb api setup
define('FACEBOOK_SDK_V4_SRC_DIR', __DIR__.'/Facebook/');

echo 'dir: ' . __DIR__ . '<br>';

require_once(__DIR__.'/Facebook/autoload.php');

$fb = new Facebook\Facebook([
 'app_id' => '1917572348517707',
 'app_secret' => '95055a6959d3808c589872cb75847f2e',
 'default_graph_version' => 'v2.10',
]);

//get bang rss
$base    = 'https://www.banggood.com/Flashdeals.html';
$cookie    = 'cookie.txt';

//url
//https://www.banggood.com/Multifunctional-Detachable-Wallet-Card-Slots-PU-Leather-Case-for-iPhone77Plus66s6Plus6sPlus-p-1154179.html?p=N8301212721949201707

	//$fetch = fetch_curl($base.'auth/login',$auth);
	$fetch = fetch_curl($base);
	//echo $fetch;
	//$pos = strpos($fetch, '<span class="buynow">');	
	//$pos2 = strpos($fetch, '<div class="w couponProducts"');
	//$fetch = substr($fetch,$pos,$pos2-$pos);
	//echo "fetch: ".$fetch;

	$products = explode('data-product-id', $fetch);
	//echo json_encode($products);
	echo '<br><br> Product 0: ' . $products[1] .'<br><br><br>';	
	echo '------------------';
	$items = array();
	$int = 0;
	foreach($products as $product)
	{
		if($int==0)
		{}else
		{
			$title_pos = strpos($product, 'alt="') + 5;
			$titleEnd_pos = strpos($product, '</a></span>');
			//$title = substr($product, $title_pos, $titleEnd_pos-$title_pos);
			$title = substr($product, $title_pos, $titleEnd_pos-$title_pos-2);

			/*if(!strpos($title, 'unbeatable')===false)
			{
				$tpos=strpos($title, 'unbeatable')-29;
				$title = substr($title, 0, $tpos);
			}else */if(!strpos($title, '">')===false)
			{
				$tpos=strpos($title, '">');
				$title = substr($title, 0, $tpos);
			}
			echo 'Title: |' . $title . '|<br>';
			$link_pos = strpos($product, '<a href=') + 9;
			$linkEnd_pos = strpos($product, '?')+1;
			$link = substr($product, $link_pos, $linkEnd_pos-$link_pos) . 'p=N8301212721949201707';
			echo 'link: |' . $link . '|<br>';

			//<div class="money_off_percent"><i>
			$disc_pos = strpos($product, '"discount"') + 11;
			$discEnd_pos = strpos($product, '% OFF');
			$disc = substr($product, $disc_pos, $discEnd_pos-$disc_pos) . '% OFF - ';
			echo 'Discount: ||' . $disc . '||<br>';
		}
		if($int!=0)
		{		
			$items[$int-1]['title']=$title;
			$items[$int-1]['link']=$link;
			$items[$int-1]['disc']=$disc . $title;
		}
		$int++;
	}
	
	//print_r($items);

if (!$link = mysql_connect('sql306.epizy.com', 'epiz_20436512', 'Alfredchicken1')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('epiz_20436512_sababa', $link)) {
    echo 'Could not select database';
    exit;
}

$sql    = 'SELECT * from banggood';
$result = mysql_query($sql, $link);

if (!$result) {
    echo "DB Error, could not query the database\n";
    echo 'MySQL Error: ' . mysql_error();
    //exit;
}

$chkrow[]=array();
$chkrow_count=0;
while ($row = mysql_fetch_assoc($result)) 
{
	$chkrow[]=$row['title'];
	$chkrow_count++;
}
mysql_free_result($result);
//print_r($chkrow);
//echo $chkrow[2];

$postCnt=1;

for($i=0;$i<$int;$i++)
//for($i=0;$i<4;$i++)
{
	$matched=0;
	for($e=0;$e<$chkrow_count;$e++)
	{
		//$chkrow = $row['title'];	
		echo "<br><br>";
		print_r($chkrow[$e]);
				echo "<br><br>";
		echo '|'.$chkrow[$e] . '| PREskipped |' . $items[$i]['title'] . '|<br>';
		if($chkrow[$e]==$items[$i]['title'])
		{	echo $chkrow[$e] . ' skipped ' . $items[$i]['title'] . '<br>';
			//skip
			$matched=1;
		}
	}
	
	if($matched==0)
	{	//post
		if($postCnt>1)
			exit;
		
		//print_r($items);			
		echo '$i: ' . $i . '<br>';
		echo '$matched: ' . $matched . '<br>';
		echo '$item: ' . $items[$i]['link'] . '<br>';
		echo 'Postcoint: ' . $postCnt . '<br>';

		//print_r($items[0]);
		$postCnt++;
		$post_link=$items[$i]['link'];
		$post_message=$items[$i]['disc'];
		
		$linkData = [
		 'link' => ''.$post_link.'',
		 'message' => ''.$post_message.''
		];
		$pageAccessToken = 'EAAbQBZAqqHUsBAICIDcLqPh5JnpS9c8g77mX606kR5iZBkoNFiJenqEYhZCz4PoFZAzqwHzZBb5xZBFdruVSCm0Sn5qJeViiugAfVYOed3y8OVZA8nS1jz9GIf0FUTZALGai2321QEkJctIdivVDZB1VZCjB6mGZClLwF1lZCzYid3UPZCwZDZD';
		
		echo '<br>';
		print_r($linkData);
		echo '<br>';


		//post to fb
		try {
		 $response = $fb->post('/me/feed', $linkData, $pageAccessToken);
		} catch(Facebook\Exceptions\FacebookResponseException $e) {
		 echo 'Graph returned an error: '.$e->getMessage();
		 exit;
		} catch(Facebook\Exceptions\FacebookSDKException $e) {
		 echo 'Facebook SDK returned an error: '.$e->getMessage();
		 exit;
		}
		$graphNode = $response->getGraphNode();
		//end fb posting

		//write to table
		if (!$link = mysql_connect('sql306.epizy.com', 'epiz_20436512', 'Alfredchicken1')) {
			echo 'Could not connect to mysql';
			exit;
		}

		if (!mysql_select_db('epiz_20436512_sababa', $link)) {
			echo 'Could not select database';
			exit;
		}

		$sql    = "INSERT INTO banggood(title) values('".$items[$i]['title']."')";
		$result = mysql_query($sql, $link);

		if (!$result) {
			echo "DB Error, could not query the database\n";
			echo 'MySQL Error: ' . mysql_error();
			//exit;
		}else{
			echo "inserted successfully - " . $items[$i]['title'] . "\n";
		}		
	}


}

?>
